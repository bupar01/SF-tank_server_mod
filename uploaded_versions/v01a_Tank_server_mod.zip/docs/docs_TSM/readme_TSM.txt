This utility provides the tank of user changing without nessesity to start the Mission Editor.
Author is bupar.
The work of utility is re-adjusted by lockie to the STA3.1, GMP1.47, mission "Fire ground".

Install through JSGM. In common case install the last in line. Mod must be located after GMP1.47. (for STA1/2)

Getting started.
1. After installation open folder: ...\Steel Fury - Kharkov 1942
2. Find file 0_tankid_change.bat and double click it
3. Consequently make a choice three times
4. Wait a minute when utility finish the work
5. Start the game, select mission 

v.01
20.02.2017
