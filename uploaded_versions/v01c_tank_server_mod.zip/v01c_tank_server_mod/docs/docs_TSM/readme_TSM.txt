This utility provides the tank of user changing without nessesity to start the Mission Editor.
Author is bupar.
The work of utility is re-adjusted by lockie to the GMP1.47, mission "Fire ground".

Install through JSGM. In common case install the last in line. Mod must be located after GMP1.47. (for STA1/2). "Firing ground" Script no accessible in STA 3.1.

Getting started.
1. After installation open folder: ...\Steel Fury - Kharkov 1942
2. Find file 0_tankid_change.bat and double click it (or drop .engscr file from mission script folder on it for other missions)
3. Consequently make a choice three times
4. Wait a minute when utility finish the work
5. Restart mission 

v.01c
12.03.2017
